<footer class="footer">
    <div class="footer-content">
        <p class="m-b-0">Copyright © 2023. All rights reserved.</p>
        {{-- <span>
            <a href="" class="text-gray m-r-15">Term &amp; Conditions</a>
            <a href="" class="text-gray">Privacy &amp; Policy</a>
        </span> --}}
    </div>
</footer>