
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>

<div class="page-header no-gutters">
    <div class="row align-items-md-center">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-5">
                    <h3><?php echo e($plan->name); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="text-md-right m-v-10">
                
                
                <button class="btn btn-warning m-r-5 ml-2 btn-sm" >
                    <span class="m-l-5"><?php echo e($plan->pricing); ?> <?php echo e(auth()->user()->agency->currency); ?></span>
                </button>

            </div>
        </div>
    </div>
</div> 


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('login_success')): ?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        <span class="sr-only">Close</span>
    </button>
    <?php echo e(Session::get('login_success')); ?>

</div>
<?php endif; ?>

<div class="row justify-content-center">
    <div class="col-md-8">
        
        <form method="POST" action="<?php echo e(route('agency.plans.order.store', $plan->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> 
            <div class="card">
                <div class="card-body">
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <label for="name">နာမည်</label>
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
                    </div>
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <label for="asset">Payment Slip / Screenshot</label>
                                <p class="form-text text-muted">
                                    ငွေပေးချေခဲ့သော ပြေစာ Screenshot ထည့်ပေးပါရန်။
                                </p>
                                <input id="asset" type="file" class="form-control <?php $__errorArgs = ['asset'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="asset" value="<?php echo e(old('asset')); ?>"  autocomplete="asset">
                                
                                <?php $__errorArgs = ['asset'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12">
                                <div class="row">
                                    <div class="col-md-3 payment_type_img">
                                        <div class="radio">
                                            <input id="kbzpay" name="payment_type" type="radio"  value="KBZ Pay">
                                            <label for="kbzpay">KBZ Pay</label>
                                        </div>
                                        <img  src="<?php echo e(asset('backend/images/payment/kbzpay.png')); ?>" class="img-fluid" onclick="paymenttype('kbzpay')">
                                        
                                    </div>
                                    <div class="col-md-3 payment_type_img">
                                        <div class="radio">
                                            <input id="kbzbank" name="payment_type" type="radio"  value="KBZ Bank">
                                            <label for="kbzbank">KBZ Bank</label>
                                        </div>
                                        <img  src="<?php echo e(asset('backend/images/payment/kbzbank.png')); ?>" class="img-fluid" onclick="paymenttype('kbzbank')">
                                        
                                    </div>
                                    <div class="col-md-3 payment_type_img">
                                        <div class="radio">
                                            <input id="ayabank" name="payment_type" type="radio"  value="AYA Bank">
                                            <label for="ayabank">AYA Bank</label>
                                        </div>
                                        <img  src="<?php echo e(asset('backend/images/payment/ayabank.png')); ?>" class="img-fluid" onclick="paymenttype('ayabank')">
                                        
                                    </div>

                                    <div class="col-md-3 payment_type_img">
                                        <div class="radio">
                                            <input id="wave" name="payment_type" type="radio" value="Wave Pay">
                                            <label for="wave">Wave Pay</label>
                                        </div>
                                        <img  src="<?php echo e(asset('backend/images/payment/wave.png')); ?>" class="img-fluid" onclick="paymenttype('wave')">
                                        
                                    </div>
                                </div>
                                
                                
                                
                        </div>
                    </div>
                    <hr>
                    <button type="submit" class="btn btn-primary float-right">
                        <?php echo e(__('အတည်ပြုသည်')); ?>

                    </button>
                </div>
                
                
                
            </div>
        
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    

    function paymenttype(id){


        document.getElementById('kbzpay').removeAttribute('checked');
        document.getElementById('kbzbank').removeAttribute('checked');
        document.getElementById('wave').removeAttribute('checked');
        document.getElementById('ayabank').removeAttribute('checked');

        document.getElementById(id).setAttribute('checked', true)
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('agency.layouts.app', ['page_action' => 'Order Plan'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\Inventory Management\inventory-management\resources\views/agency/orders/create.blade.php ENDPATH**/ ?>