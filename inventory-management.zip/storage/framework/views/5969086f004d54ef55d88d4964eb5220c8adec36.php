<!-- Modal -->
<div class="modal modal-right fade " id="filter">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="side-modal-wrapper">
                <form action="<?php echo e(route('agency.brands.index')); ?>" method="post">
                    <?php echo csrf_field(); ?> <?php echo method_field("GET"); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Filter Category</h5>
                    
                </div>

                <div class="modal-body">
                    
                        <div class="form-group">
                          <label for="">Search With Name</label>
                          <input type="text"
                            class="form-control" name="name" id="name" value="<?php echo e(request()->get('name','')); ?>" aria-describedby="helpId" placeholder="">
                        </div>

                        
                    
                </div>
                <div class="modal-footer">
                    <a type="button" class="btn btn-default mr-3" href="<?php echo e(route('agency.brands.index')); ?>">Reset</a>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>

            </form>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Freelance\Inventory Management\inventory-management\resources\views/agency/brands/parts/filter_form.blade.php ENDPATH**/ ?>