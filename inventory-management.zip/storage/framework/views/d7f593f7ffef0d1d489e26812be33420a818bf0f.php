
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/backend/owl/assets/owl.carousel.min.css')); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header no-gutters ">
    
    
    <div class="d-md-flex m-b-15 align-items-center justify-content-between">
        <div class="media align-items-center m-b-15">
            
            <div class="m-l-15">
                <h4 class="m-b-0">Welcome, <?php echo e(auth()->user()->name); ?></h4>
                <p class="text-muted m-b-0">
                    <?php switch($agency->status):
                    case ('active'): ?>
                    <span class="badge badge-pill badge-cyan">Active</span>
                    <?php break; ?>
                    <?php case ('pending'): ?>
                    <span class="badge badge-pill badge-gold">Pending</span>
                    <?php break; ?>
                    <?php default: ?>
                    <span class="badge badge-pill badge-red">Cancled</span>
                    <?php endswitch; ?>
                    
                    
                </p>
            </div>
        </div>
        <div class="m-b-15">
            <a href="<?php echo e(route('agency.plans.index')); ?>" class="btn btn-success">
                <i class="anticon anticon-to-top"></i>
                <span>Upgreat Plan</span>
            </a>
        </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class=" owl-carousel">
    <div class="">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <i class="font-size-40 text-primary anticon anticon-appstore"></i>
                    <div class="m-l-15">
                        <p class="m-b-0 text-muted">Products</p>
                        <h4 class="m-b-0 "><?php echo e($products->count()); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <i class="font-size-40 text-primary anticon anticon-shopping-cart"></i>
                    <div class="m-l-15">
                        <p class="m-b-0 text-muted">Orders</p>
                        <h4 class="m-b-0 "><?php echo e($sales->count()); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <i class="font-size-40 text-primary anticon anticon-idcard"></i>
                    <div class="m-l-15">
                        <p class="m-b-0 text-muted">Customers</p>
                        <h4 class="m-b-0 "><?php echo e($customers->count()); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <i class="font-size-40 text-primary anticon anticon-solution"></i>
                    <div class="m-l-15">
                        <p class="m-b-0 text-muted">Suppliers</p>
                        <h4 class="m-b-0 "><?php echo e($suppliers->count()); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>

<div class="row">
    <div class="col-sm-6 col-md-3">
        <a href="<?php echo e(route('agency.products.create')); ?>">
            <div class="card">
                <div class="card-body">
                    <div class="align-items-center">
                        <i class="font-size-40 text-primary anticon anticon-plus-square"></i>
                    </div>
                    
                    <div class="media align-items-center">
                        
                        <p class="m-b-0 text-center">ADD Product</p>
                    </div>
                </div>
            </div>
        </a>
    </div>

    <div class="col-sm-6 col-md-3">
        <a href="<?php echo e(route('agency.categories.index')); ?>">
            <div class="card">
                <div class="card-body">
                    <div class="align-items-center">
                        <i class="font-size-40 text-primary anticon anticon-plus-square"></i>
                    </div>
                    
                    <div class="media align-items-center">
                        
                        <p class="m-b-0 text-center">ADD Category</p>
                    </div>
                </div>
            </div>
        </a>
        
    </div>


</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('/backend/owl/owl.carousel.min.js')); ?>"></script>

<script>
    $(document).ready(function(){
  $(".owl-carousel").owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:2
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }
  });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('agency.layouts.app', ['page_action' => auth()->user()->agency->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\Inventory Management\inventory-management\resources\views/agency/index.blade.php ENDPATH**/ ?>