<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>41 Inventory - <?php echo e($page_action ?? ''); ?></title>

    <link rel="shortcut icon" href="<?php echo e(asset('backend/images/logo/favicon.png')); ?>" type="image/x-icon" />

    <!-- Scripts -->
    
    <?php echo $__env->yieldContent('style'); ?>
    <!-- Styles -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.2/umd/popper.min.js"></script>
    <link href="<?php echo e(asset('backend/css/app.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/css/style.css')); ?>" rel="stylesheet">

    

    <style>
        @font-face {
      font-family: 'MyanmarSabae';
      src: url('<?php echo e(asset('asset/fonts/MyanmarSabae.ttf')); ?>');
        }
        
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('asset/style.css')); ?>">

</head>
<body>
    <div class="app">
        <div class="layout">

            <!-- Side Nav START -->
            <?php echo $__env->make('frontend.layouts.parts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Side Nav END -->


            <!-- Header START -->
            <?php echo $__env->make('frontend.layouts.parts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Header END -->
            
            <!-- Page Container START -->
            <div class="page-container" style="padding: 0">
                
                
                <!-- Content  -->
                <div class="main-content" style="padding-top: 20px">
                    <?php echo $__env->yieldContent('breadcrumb'); ?>
                    
                    <?php echo $__env->yieldContent('content'); ?>
                    <!-- Content  -->
                </div>
                <!-- Content Wrapper END -->

                <!-- Footer START -->
                <?php echo $__env->make('frontend.layouts.parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Footer END -->

            </div>
            <!-- Page Container END -->

            
        </div>
    </div>

    <!-- Core Vendors JS -->
    <script src="<?php echo e(asset('backend/js/vendors.min.js')); ?>"></script>

    

    <!-- Core JS -->
    <script src="<?php echo e(asset('backend/js/app.min.js')); ?>"></script>

    <!-- page js -->
    <?php echo $__env->yieldContent('script'); ?>

</body>
</html>
<?php /**PATH D:\Freelance\Inventory Management\inventory-management\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>