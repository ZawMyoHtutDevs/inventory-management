
<?php $__env->startSection('style'); ?>

<script src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header mb-3">
    <h2 class="header-title"><?php echo e($sale->order_number); ?></h2>
    <div class="header-sub-title">
        <nav class="breadcrumb breadcrumb-dash">
            <a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Dashboard</a>
            <a class="breadcrumb-item" href="<?php echo e(route('agency.sales.list')); ?>">Sales</a>
            <span class="breadcrumb-item active">Invoice</span>
        </nav>
    </div>

    
    <button class="btn btn-primary float-right btn-sm" onclick="downloadimage()"> <i class="anticon anticon-cloud-download"></i> Download Invoice</button>
    
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container" id="htmltoimage" style="width: 1000px">

    <div class="card">
        <div class="card-body">
            <div id="invoice" class="p-h-30">
                <div class="m-t-15 lh-2">
                    <div class="inline-block">
                        <img class="img-fluid" width="70px" 
                        src="
                        <?php if(!empty(auth()->user()->agency->asset)): ?>
                            <?php echo e(asset('agencies/'.auth()->user()->agency->unit_id.'/'.auth()->user()->agency->asset)); ?>

                        <?php else: ?>
                            <?php echo e(asset('backend/images/client_logo.png')); ?>

                        <?php endif; ?>
                        " alt="">
                        <address class="p-l-10">
                            <span class="font-weight-semibold text-dark"><?php echo e(auth()->user()->agency->name); ?></span><br>
                            <span><?php echo e(auth()->user()->agency->business_type); ?></span><br>
                            <abbr class="text-dark" title="Phone">Phone:</abbr>
                            <span><?php echo e(auth()->user()->agency->phone); ?></span>
                        </address>
                    </div>
                    <div class="float-right">
                        <h2>INVOICE</h2>
                    </div>
                </div>
                <div class="row m-t-20 lh-2">
                    <div class="col-9">
                        <h3 class="p-l-10 m-t-10">Invoice To:</h3>
                        <address class="p-l-10 m-t-10">
                            <span class="font-weight-semibold text-dark"><?php echo e($sale->customer->name); ?></span><br>
                            <span>Phone </span><br>
                            <span><?php echo e($sale->customer->phone); ?></span>
                        </address>
                    </div>
                    <div class="col-3">
                        <div class="m-t-80">
                            <div class="text-dark text-uppercase d-inline-block">
                                <span class="font-weight-semibold text-dark">Invoice No :</span></div>
                            <div class="float-right"><?php echo e($sale->order_number); ?></div>
                        </div>
                        <div class="text-dark text-uppercase d-inline-block">
                            <span class="font-weight-semibold text-dark">Date :</span>
                        </div>
                        <div class="float-right"><?php echo e(Carbon\Carbon::parse($sale->created_at)->format('M d Y')); ?></div>
                    </div>
                </div>
                <div class="m-t-20">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Items</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $json_arry = json_decode($sale->products_data);
                                    $id = 1;
                                    $sub_total_price = 0;
                                    foreach($json_arry as $key => $json) { 
                                        $sub_total_price += $json->total;

                                    }
                                ?>

                                <?php $__currentLoopData = $json_arry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($id++); ?></th>
                                        <td><?php echo e($data->name); ?></td>
                                        <td><?php echo e($data->count); ?></td>
                                        <td><?php echo e($data->price); ?> <?php echo e(auth()->user()->agency->currency); ?></td>
                                        <td><?php echo e($data->total); ?> <?php echo e(auth()->user()->agency->currency); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    <div class="row m-t-30 lh-1-8">
                        <div class="col-sm-12">
                            <div class="float-right text-right">
                                <p>Sub - Total amount: <?php echo e($sub_total_price); ?> <?php echo e(auth()->user()->agency->currency); ?></p>
                                <p>Discount : <?php echo e($sale->discount_price ?? '0'); ?> <?php echo e(auth()->user()->agency->currency); ?> </p>
                                <hr>
                                <h3><span class="font-weight-semibold text-dark">Total :</span> <?php echo e($sale->total_price); ?> <?php echo e(auth()->user()->agency->currency); ?></h3>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    // var node = document.getElementById('my-node');
    // var btn = document.getElementById('result');
    // btn.onclick = function() {
    //   domtoimage.toBlob(document.getElementById('my-node'))
    //     .then(function(blob) {
    //       window.saveAs(blob, 'my-node.png');
    //     });
    // }

    function downloadimage() {
                /*var container = document.getElementById("image-wrap");*/ /*specific element on page*/
                var container = document.getElementById("htmltoimage");; /* full page */
                html2canvas(container, { allowTaint: true }).then(function (canvas) {

                    var link = document.createElement("a");
                    document.body.appendChild(link);
                    link.download = "html_image.jpg";
                    link.href = canvas.toDataURL();
                    link.target = '_blank';
                    link.click();
                });
            }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('agency.layouts.app', ['page_action' => 'Invoice'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\Inventory Management\inventory-management\resources\views/agency/sales/detail.blade.php ENDPATH**/ ?>