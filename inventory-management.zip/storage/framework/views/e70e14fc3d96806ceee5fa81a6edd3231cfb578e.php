
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>

<div class="page-header no-gutters">
    <div class="row align-items-md-center">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-5">
                    <h3>Sale List</h3>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="text-md-right m-v-10">
                <span class="text-muted pr-3 pt-2 p">Total Result: <?php echo e(count($sales)); ?></span>
                
                <button class="btn btn-default m-r-5 ml-2 btn-sm" data-toggle="modal" data-target="#filter" >
                    <i class="anticon anticon-filter"></i>
                    <span class="m-l-5">Filter</span>
                </button>


                <a class="btn btn-primary m-r-5 ml-2 btn-sm" href="<?php echo e(route('agency.sales.index')); ?>" >
                    <i class="anticon anticon-plus"></i>
                    <span class="m-l-5">New</span>
                </a>

            </div>
        </div>
    </div>
</div> 


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        <span class="sr-only">Close</span>
    </button>
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>

<div class="container-fluid">
    
    <div id="card-view">
        <div class="row">

            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 col-6" style="padding-right: 5px;
            padding-left: 3px;">
                <div class="card" style="margin-bottom: 10px;">
                    <div class="card-body" style="padding-top: 0.7em; padding-left: 0.3em; padding-right: 0.3em;">
                        <div class="d-flex align-items-center" >
                            
                            <div class="m-l-10">
                                <div class="pb-1 text-dark font-weight-semibold">Invoice No(<?php echo e($data->order_number); ?>)</div>
                                <div class="pb-1 opacity-07 font-size-15"><?php echo e($data->total_price); ?> <?php echo e(auth()->user()->agency->currency); ?></div>
                                <div class="pb-1 opacity-07 font-size-13">

                                    <?php switch($data->status):
                                        case ('Delivery Ongoing'): ?>
                                        <span class="badge badge-pill badge-info">Delivery Ongoing</span>
                                            <?php break; ?>
                                        <?php case ('Completed'): ?>
                                        <span class="badge badge-pill badge-success">Completed</span>
                                            <?php break; ?>
                                        <?php case ('Payment Pending'): ?>
                                        <span class="badge badge-pill badge-warning">Payment Pending</span>
                                            <?php break; ?>
                                        <?php case ('On Hold'): ?>
                                        <span class="badge badge-pill badge-warning">On Hold</span>  
                                            <?php break; ?>
                                        <?php default: ?>
                                        <span class="badge badge-pill badge-danger">Cancelled</span>
                                    <?php endswitch; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer" style="padding: 0.7rem;">
                        <div class="text-right">

                           

                            <a href="<?php echo e(route('agency.sales.invoice.pdf', $data->order_number)); ?>" class="btn btn-primary btn-xs">Download</a>
                            <a href="<?php echo e(route('agency.sales.show', $data->order_number)); ?>" class="btn btn-info btn-xs">View</a>
                            
                        </div>
                    </div>
                </div>
                
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>


    <?php echo $sales->appends(array("name" => request()->get('name',''),"status" => request()->get('status','') ))->links(); ?>

</div>


<?php echo $__env->make('agency.sales.parts.list_filter_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php if($errors->any()): ?>
<script>
    $('#addnew').modal('show')
</script>
<?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('agency.layouts.app', ['page_action' => 'Sales List'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\Inventory Management\inventory-management\resources\views/agency/sales/list.blade.php ENDPATH**/ ?>