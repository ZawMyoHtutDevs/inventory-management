
<?php $__env->startSection('style'); ?>
<!-- page css -->
<link href="<?php echo e(asset('backend/vendors/datatables/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>

<div class="page-header">
    <h2 class="header-title">Order History</h2>
    <div class="header-sub-title">
        <nav class="breadcrumb breadcrumb-dash">
            <a href="<?php echo e(route('home')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Dashboard</a>
            <span class="breadcrumb-item active">Order History</span>
        </nav>
    </div>
    
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        <span class="sr-only">Close</span>
    </button>
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>


<div class="row">
    
    <div class="col-md-12">
        <div class="card">
            
            
            <div class="card-body">
                <table id="data-table" class="table" class="table table-inverse ">
                    <thead>
                        <tr>
                            <th>Status</th>
                            <th>Payment Type</th>
                            <th>Plan</th>
                            <th>Price</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php switch($data->status):
                                    case ('active'): ?>
                                        <span class="badge badge-success">Active</span>
                                        <?php break; ?>
                                    <?php case ('pending'): ?>
                                        <span class="badge badge-warning">Pending</span>
                                        <?php break; ?>
                                    <?php default: ?>
                                        <span class="badge badge-danger">Cancelled</span>
                                <?php endswitch; ?>
                            </td>
                            <td><?php echo e($data->payment_type); ?></td>
                            <td><?php echo e($data->plan->name); ?></td>
                            <td>
                                <?php echo e($data->total_price); ?> <?php echo e(auth()->user()->agency->currency); ?>

                            </td>
                            <td>       
                                
                                <a href="<?php echo e(route('agency.plans.view', $data->id)); ?>" class="btn btn-icon btn-hover btn-sm btn-rounded pull-right text-primary">
                                    <i class="anticon anticon-eye"></i>
                                </a>
                                
                               
                                
                                
                                
                                
                                
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                    
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- page js -->
<script src="<?php echo e(asset('backend/vendors/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/vendors/datatables/dataTables.bootstrap.min.js')); ?>"></script>

<script>
    
    
    $('#data-table').DataTable();
    
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('agency.layouts.app', ['page_action' => 'Order History'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\Inventory Management\inventory-management\resources\views/agency/orders/index.blade.php ENDPATH**/ ?>