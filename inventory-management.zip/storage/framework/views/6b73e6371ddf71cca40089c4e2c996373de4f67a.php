<footer class="footer">
    <div class="footer-content">
        <p class="m-b-0">Copyright © 2023. All rights reserved.</p>
        
    </div>
</footer><?php /**PATH D:\Freelance\Inventory Management\inventory-management\resources\views/agency/layouts/parts/footer.blade.php ENDPATH**/ ?>