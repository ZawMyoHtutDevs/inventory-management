<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Online Inventory</title>
    <link rel="shortcut icon" href="<?php echo e(asset('backend/images/logo/favicon.png')); ?>" type="image/x-icon" />

    <!-- Scripts -->
    
    <?php echo $__env->yieldContent('style'); ?>
    <!-- Styles -->
    <link href="<?php echo e(asset('backend/css/app.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/css/style.css')); ?>" rel="stylesheet">
    

</head>
<body>
    <div class="app">
        <div class="layout">
            <!-- Header START -->
            <?php echo $__env->make('admin.layouts.parts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Header END -->

            <!-- Side Nav START -->
            <?php echo $__env->make('admin.layouts.parts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Side Nav END -->

            
            <!-- Page Container START -->
            <div class="page-container">
                
                
                <!-- Content  -->
                <div class="main-content">
                    <?php echo $__env->yieldContent('breadcrumb'); ?>
                    
                    <?php echo $__env->yieldContent('content'); ?>
                    <!-- Content  -->
                </div>
                <!-- Content Wrapper END -->

                <!-- Footer START -->
                <?php echo $__env->make('admin.layouts.parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Footer END -->

            </div>
            <!-- Page Container END -->

            
        </div>
    </div>

    <!-- Core Vendors JS -->
    <script src="<?php echo e(asset('backend/js/vendors.min.js')); ?>"></script>

    

    <!-- Core JS -->
    <script src="<?php echo e(asset('backend/js/app.min.js')); ?>"></script>

    <!-- page js -->
    <?php echo $__env->yieldContent('script'); ?>

</body>
</html>
<?php /**PATH D:\Freelance\Inventory Management\inventory-management\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>