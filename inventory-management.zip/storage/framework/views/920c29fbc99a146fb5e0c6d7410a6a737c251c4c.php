<div class="modal fade" id="promo">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            
            <div class="modal-body p-0">
                <button type="button" class="close" data-dismiss="modal">
                    <i class="anticon anticon-close" style="margin-right: 10px;
                    color: white;"></i>
                </button>
                <a href="<?php echo e(route('frontend.register')); ?>">
                    <img src="<?php echo e(asset('asset/promo.png')); ?>" alt="" class="promo_img">
                </a>
            </div>
            
        </div>
    </div>
</div><?php /**PATH D:\Freelance\Inventory Management\inventory-management\resources\views/frontend/layouts/promo.blade.php ENDPATH**/ ?>