<!-- Modal -->
<div class="modal modal-right fade " id="filter">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="side-modal-wrapper">
                <form action="<?php echo e(route('agency.products.index')); ?>" method="get">
                    
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Filter Product</h5>
                    
                </div>

                <div class="modal-body">
                    
                        <div class="form-group">
                          <label for="">Search With Name</label>
                          <input type="text"
                            class="form-control" name="name" id="name" value="<?php echo e(request()->get('name','')); ?>" aria-describedby="helpId" placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="">Search With Brand</label>
                            <select name="brand_id" id="" class="form-control">
                                <option value="">Select Brand</option>
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Search With Category</label>
                            <select name="category_id" id="" class="form-control">
                                <option value="">Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Search With Supplier</label>
                            <select name="supplier_id" id="" class="form-control">
                                <option value="">Select Supplier</option>
                                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Search With Status</label>
                            <select name="status" id="" class="form-control">
                                <?php if(request()->get('status') == '0'): ?>
                                <option value="0">Inactive</option>
                                <?php else: ?>
                                <option value="1">Active</option>
                                <?php endif; ?>
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                                
                            </select>
                        </div>

                        
                    
                </div>
                <div class="modal-footer">
                    <a type="button" class="btn btn-default mr-3" href="<?php echo e(route('agency.products.index')); ?>">Reset</a>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>

            </form>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Freelance\Inventory Management\inventory-management\resources\views/agency/products/parts/filter_form.blade.php ENDPATH**/ ?>