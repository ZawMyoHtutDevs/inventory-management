
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header mb-3 p-5">
    <h2 class="header-title">Pricing Plan</h2>
    <div class="header-sub-title">
        <nav class="breadcrumb breadcrumb-dash">
            <a href="<?php echo e(route('frontend.index')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>
            
            <span class="breadcrumb-item active">Pricing</span>
        </nav>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <?php echo $__env->make('frontend.layouts.plan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php echo $__env->make('frontend.layouts.promo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    function openPromo(){
        $('#promo').modal('show')
    }
setTimeout(openPromo, 5000);
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', ['page_action' => 'Contact'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\Inventory Management\inventory-management\resources\views/frontend/pricing_page.blade.php ENDPATH**/ ?>