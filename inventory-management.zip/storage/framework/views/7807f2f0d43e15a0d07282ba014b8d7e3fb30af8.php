
<?php $__env->startSection('style'); ?>
<!-- page css -->
<link href="<?php echo e(asset('backend/vendors/datatables/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">

<style>
    #data-table_filter input{
        max-width: 200px !important;
    }
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h2 class="header-title">All Agencies</h2>
    <div class="header-sub-title">
        <nav class="breadcrumb breadcrumb-dash">
            <a href="<?php echo e(route('home')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Dashboard</a>
            <span class="breadcrumb-item active">Agencies</span>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        <span class="sr-only">Close</span>
    </button>
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>

<div class="row">
    
    <div class="col-md-12">
        <div class="card">
            <div class="card-header mt-3 h3"><?php echo e(__('Agency List')); ?> 
                <a href="<?php echo e(route('admin.agencies.create')); ?>" class="btn btn-primary m-r-5 float-right">Add <i class="anticon anticon-plus-square"></i></a>
            </div>
            
            <div class="card-body">
                <table id="data-table" class="table" class="table table-inverse ">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Plan</th>
                            <th>Status</th>
                            <th>Remaining</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e($data->plan->name ?? "No Plan Active"); ?></td>
                            <td>
                                <?php switch($data->status):
                                    case ('active'): ?>
                                    <span class="badge badge-success">Active</span>
                                        <?php break; ?>
                                    <?php case ('pending'): ?>
                                    <span class="badge badge-warning">Pending</span>
                                        <?php break; ?>
                                    <?php default: ?>
                                    <span class="badge badge-danger">Cancelled</span>
                                <?php endswitch; ?>
                            </td>
                            <td>
                                <?php echo e(Carbon\Carbon::now()->diffForHumans($data->end_date, ['parts' => 2])); ?>

                            </td>
                            <td>
                               
                                
                                <a href="<?php echo e(route('admin.agencies.edit', $data->id)); ?>" class="btn btn-icon btn-hover btn-sm btn-rounded pull-right text-primary">
                                    <i class="anticon anticon-edit"></i>
                                </a>
                                
                                
                                
                                
                                
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                    
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- page js -->
<script src="<?php echo e(asset('backend/vendors/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/vendors/datatables/dataTables.bootstrap.min.js')); ?>"></script>

<script>
    
    
    $('#data-table').DataTable();
    
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\Inventory Management\inventory-management\resources\views/admin/agencies/index.blade.php ENDPATH**/ ?>